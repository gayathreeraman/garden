<?php 

namespace App\Http\Controllers;

use Request;
use App\Models\customer;
use App\Models\garden;
use App\Models\gardenItem;

class GardenController extends Controller{

	public function saveGardenLayout(){

		
	}
	
}