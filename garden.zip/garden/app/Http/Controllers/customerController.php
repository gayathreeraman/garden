<?php 

namespace App\Http\Controllers;

use Request;
use App\Models\customer;

class CustomerController extends Controller{
	
}