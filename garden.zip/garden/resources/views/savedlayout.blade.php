<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href='css/style.css' rel="stylesheet" type="text/css" >
    </head>
    <body>

    <div>
    
    Project1 Name of the project Date created delete

    </div>
    
        

        

</body>
</html>