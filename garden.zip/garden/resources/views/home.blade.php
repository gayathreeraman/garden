Hello this is home
<a href="/auth/logout">LOGOUT</a>